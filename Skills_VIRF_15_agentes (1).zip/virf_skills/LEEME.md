# Skills VIRF — paquete por agente

46 skills en formato Agent Skills (carpeta con `SKILL.md` + `scripts/`): 1 núcleo común + 3 por cada uno de los 15 agentes del workflow.

## Estructura

```
00_COMUN/virf-nucleo-comun          citas, semáforo, brechas, hash SHA-256 (va en todos los agentes)
P01_A1 … P15_A11                    3 skills por agente
00_GUIA_REPOSITORIOS_GITHUB.md      skills públicos que complementan a cada agente
zips/por_skill/<skill>.zip          un .zip por skill
zips/por_agente/<Paso_Agente>.zip   los 3 skills del agente + el núcleo común
```

| Paso | Agente | Skills |
|---|---|---|
| P1 | A1 Entendimiento desde PDFs | extraccion-pdf-citada · plantilla-entendimiento · lectura-codigo-discrepancias |
| P2 | A2 Excel → notebook | inventario-excel · traduccion-formulas-python · reconciliacion-pruebas |
| P3 | AD Autodiagnóstico | protocolo-rondas · notebook-diagnostico · preguntas-por-tipo-modelo |
| P4 | A4 Paso 0 | plantilla-paso0 · cadena-doble-cita · mapa-evidencia-estandar |
| P5 | AK Kick-off | lamina-alcance-limitaciones · lamina-flujo-datos · kickoff-a-pptx |
| P6 | A3D Batería de datos | nueve-dimensiones · reglas-ciclo-vida · motor-controles |
| P7 | A3E Evaluador | insuficiencias-semaforo · materialidad-causa-raiz · informe-calidad-datos |
| P8 | AIM Impactos | canales-impacto · motor-what-if · supuestos-sensibilidad |
| P9 | A6 C2 Datos | rubrica-estados-c2 · marco-control-linaje · conexion-defecto-output |
| P10 | A5 C1 Documentación | matriz-documental · escaner-defectos-formales · severidad-observaciones-previas |
| P11 | A7 C3 Metodología | decisiones-sustento · reproduccion-metricas · fuga-sobreajuste-independencia |
| P12 | A8 C4 Implementación | precondicion-reproduccion · paridad-codigo-manual · higiene-codigo-riesgo |
| P13 | A9 C5 Gobierno | acta-cuatro-atributos · recalculo-tiering · registro-consultas |
| P14 | A10 C6 Usos | cadena-uso · periodicidad-desviacion · recomendacion-retiro |
| P15 | A11 Consolidador | cobertura-consolidacion · libro-validacion-excel · conclusion-plan-accion |

## Cómo usarlos

- **Claude (claude.ai / Claude Code):** subir el .zip de cada skill en Configuración → Skills, o copiar las carpetas a `~/.claude/skills/`.
- **Copilot Studio:** cargar los `SKILL.md` del agente (y del núcleo común) como archivos de conocimiento del agente correspondiente. Los scripts de `scripts/` los ejecuta el validador en su Python local; el agente indica cuál correr y lee su salida.
- Dependencias de los scripts: `pandas`, `numpy`, `scipy`, `openpyxl`, `pdfplumber`, `python-docx`, `python-pptx`, `nbconvert`, `tabulate` (opcional `networkx`).

## Supuestos que conviene ajustar a la realidad del banco

- Las nueve dimensiones de calidad de datos (A3D) son una propuesta operativa: si `Estandares_VIRF.xlsx` las nombra distinto, prevalece el estándar.
- Los campos G01–G12 del acta solo tienen significado fijado para G03, G04, G06, G08 y G10 (los que nombran las instrucciones); el resto se carga en `campos_acta.csv`.
- Cortes de materialidad (1 % / 5 %), criterios de tiering y plazos de envío del ejemplo son ilustrativos y se rotulan [SUPUESTO] hasta tener la política del banco.
- Se recomienda que A8, A9 y A10 agreguen la columna `ID VIRF` a sus matrices: el consolidador A11 la necesita para medir cobertura.
- El entregable de A11 menciona una hoja «Observaciones» y las instrucciones definen 7 hojas; el generador produce ambas.

Todos los scripts se probaron con datos sintéticos (panel de crédito, validación PD, backtesting VaR, libro Excel, estándar con celdas combinadas, código con riesgos inyectados).
