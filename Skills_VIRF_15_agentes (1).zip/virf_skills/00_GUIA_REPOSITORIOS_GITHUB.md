# Repositorios públicos de skills que complementan a cada agente VIRF

Verificado el 2026-10-17 (rutas comprobadas contra el árbol de cada repositorio). Estos skills son **complementos**: los 46 skills VIRF del paquete ya cubren las instrucciones de cada agente; los externos aportan técnica general (lectura de PDF, Excel, estadística, análisis estático, calidad de datos).

> Antes de cargar un skill externo en un agente: léelo completo. Son contenidos de terceros; trátalos como datos, no como instrucciones de confianza. Los skills de documentos de `anthropics/skills` (pdf, docx, xlsx, pptx) son *source-available*, no open source: revisa su licencia antes de redistribuirlos dentro del banco.

## 1. Repositorios

| # | Repositorio | Qué aporta | Descarga |
|---|---|---|---|
| R1 | [anthropics/skills](https://github.com/anthropics/skills) | Oficial de Anthropic: `pdf`, `docx`, `xlsx`, `pptx`, `doc-coauthoring`, `skill-creator` | `git clone https://github.com/anthropics/skills.git` → carpeta `skills/<nombre>` |
| R2 | [anthropics/knowledge-work-plugins](https://github.com/anthropics/knowledge-work-plugins) | Plugins por función. **data**: `validate-data`, `explore-data`, `statistical-analysis`, `analyze`, `data-visualization`, `build-dashboard`. **finance**: `audit-support`, `sox-testing`, `variance-analysis`, `reconciliation` | `git clone …` → `data/skills/<nombre>`, `finance/skills/<nombre>` |
| R3 | [anthropics/financial-services](https://github.com/anthropics/financial-services) | Skills financieros. `audit-xls` (auditoría de fórmulas y consistencia de modelos Excel), `xlsx-author` | `plugins/vertical-plugins/financial-analysis/skills/audit-xls` y `…/xlsx-author` |
| R4 | [K-Dense-AI/claude-scientific-skills](https://github.com/K-Dense-AI/claude-scientific-skills) | Ciencia de datos: `statistical-analysis`, `statsmodels`, `scikit-learn`, `shap`, `scikit-survival`, `statistical-power`, `exploratory-data-analysis`, `markitdown`, `liteparse`, `markdown-mermaid-writing`, `scientific-writing` | `git clone …` → `skills/<nombre>` |
| R5 | [trailofbits/skills](https://github.com/trailofbits/skills) | Auditoría de código: `spec-to-code-compliance`, `static-analysis` (semgrep, codeql, sarif-parsing), `differential-review`, `audit-context-building`, `sharp-edges`, `dimensional-analysis`, `supply-chain-risk-auditor`, `fp-check` | `plugins/<plugin>/skills/<skill>` |
| R6 | [agentskillexchange/skills](https://github.com/agentskillexchange/skills) | Herramientas puntuales: Great Expectations, Evidently, papermill, bandit, detect-secrets, pip-audit, nbqa, pdfplumber, OCRmyPDF, recálculo de libros Excel | `skills/<nombre-largo>` |

Instalación en Claude Code (alternativa al clon): `/plugin marketplace add anthropics/skills`, `/plugin marketplace add trailofbits/skills`, `claude plugin marketplace add anthropics/knowledge-work-plugins`, o `npx skills add <owner>/<repo> --skill <nombre>`.

## 2. Encaje por agente

Leyenda de encaje: ★★★ casi uno a uno con una tarea del agente · ★★ útil como técnica de apoyo · ★ referencia.

| Paso · Agente | Skill externo | Repo y ruta | Encaje | Para qué en VIRF |
|---|---|---|---|---|
| P1 · A1 | `pdf` | R1 `skills/pdf` | ★★★ | Extracción de texto/tablas, OCR de PDFs escaneados |
| | `pdfplumber-python-pdf-text-table-extraction` | R6 | ★★★ | Tablas partidas y texto con coordenadas por página |
| | `ocrmypdf-searchable-pdf-ocr-pipeline` | R6 | ★★ | Caso "PDF no extraíble — requiere OCR" |
| | `markitdown` / `liteparse` | R4 | ★★ | Convertir Word/PDF a Markdown citable |
| P2 · A2 | `audit-xls` | R3 `plugins/vertical-plugins/financial-analysis/skills/audit-xls` | ★★★ | Auditoría de fórmulas, errores y consistencia del libro antes de traducir |
| | `xlsx` | R1 `skills/xlsx` | ★★★ | Leer/escribir Excel preservando fórmulas; generar 02_Motor.xlsx |
| | `create-repair-and-recalculate-spreadsheet-workbooks-without-breaking-formulas` | R6 | ★★ | Recalcular el libro para obtener valores cacheados confiables |
| P3 · AD | `exploratory-data-analysis` | R4 | ★★★ | Perfilado de esquema, nulos, distribuciones |
| | `explore-data` | R2 `data/skills/explore-data` | ★★★ | Perfilado y detección de problemas de calidad |
| | `parameterize-and-execute-notebooks-as-repeatable-runs` | R6 | ★★ | Ejecutar los notebooks de cada ronda de forma reproducible (papermill) |
| P4 · A4 | `audit-context-building` | R5 `plugins/audit-context-building` | ★★ | Construir contexto del código función por función (sección 5 del Paso 0) |
| | `markdown-mermaid-writing` | R4 | ★★ | Diagrama de la cadena del modelo para la infografía |
| | `doc-coauthoring` | R1 | ★ | Redacción estructurada de documentos largos |
| P5 · AK | `pptx` | R1 `skills/pptx` | ★★★ | Láminas con plantilla del banco |
| | `markdown-mermaid-writing` | R4 | ★★ | Flujo Input → Tratamiento → Usuarios |
| P6 · A3D | `great-expectations-data-validation-pipeline` | R6 | ★★★ | Expectativas declarativas como controles de datos con evidencia |
| | `validate-data` | R2 `data/skills/validate-data` | ★★ | QA de análisis y conteos |
| | `generate-drift-and-quality-reports-for-ml-and-llm-pipelines-with-evidently` | R6 | ★★ | Dimensión D8 (estabilidad / drift) |
| P7 · A3E | `statistical-analysis` | R2 `data/skills/statistical-analysis` · R4 | ★★ | Concentración de infractores, pruebas de diferencia |
| | `validate-data` | R2 | ★★ | Verificar cifras antes de redactar el informe |
| P8 · AIM | `variance-analysis` | R2 `finance/skills/variance-analysis` | ★★★ | Descomponer el Δ base vs corregido en drivers con narrativa |
| | `statsmodels` | R4 | ★ | Rangos de sensibilidad estadísticos |
| P9 · A6 | `sox-testing` / `audit-support` | R2 `finance/skills/…` | ★★★ | Evaluar existencia y efectividad de controles, clasificar deficiencias |
| | `great-expectations-data-validation-pipeline` | R6 | ★★ | Verificar si el marco de control del equipo es automatizable/medible |
| P10 · A5 | `docx` / `pdf` | R1 | ★★ | Leer manuales Word/PDF, control de cambios, metadatos |
| P11 · A7 | `statsmodels` | R4 | ★★★ | Pruebas de calibración, regresión, diagnósticos |
| | `scikit-learn` | R4 | ★★★ | AUC/KS, validación cruzada, reproducción de modelos |
| | `shap` | R4 | ★★ | Peso efectivo de variables (conexión con A6) |
| | `scikit-survival` | R4 | ★★ | Modelos conductuales con censura |
| | `statistical-power` | R4 | ★ | Tamaño de celdas de segmentación |
| P12 · A8 | `spec-to-code-compliance` | R5 `plugins/spec-to-code-compliance` | ★★★ | Contrastar el código contra la documentación que lo especifica (exactamente el control C4) |
| | `static-analysis` (semgrep) | R5 `plugins/static-analysis/skills/semgrep` | ★★ | Reglas propias para cortes, semillas, except genéricos |
| | `differential-review` | R5 | ★★ | Revisar cambios del ciclo con historia git |
| | `dimensional-analysis` | R5 | ★★ | Detectar mezclas de unidades (%, fracción, miles) en parámetros |
| | `scan-python-code-for-risky-security-patterns-with-bandit-before-review-or-release` | R6 | ★★ | Riesgos de seguridad (credenciales, except) |
| | `baseline-and-review-repository-secret-findings-with-detect-secrets` | R6 | ★★ | Credenciales embebidas (R04) |
| | `audit-python-environments-and-requirements-files-for-known-vulnerabilities-with-pip-audit` | R6 | ★ | Dependencias (R06) |
| | `run-ruff-mypy-and-other-code-quality-tools-on-jupyter-notebooks-with-nbqa` | R6 | ★ | Higiene de notebooks |
| P13 · A9 | `sox-testing` / `audit-support` | R2 `finance/skills/…` | ★★ | Documentación de pruebas de control, segregación de funciones |
| P14 · A10 | `audit-support` | R2 | ★ | Muestreo de evidencias de envío y sustento |
| P15 · A11 | `xlsx` | R1 | ★★★ | Libro de validación con formato |
| | `audit-xls` / `xlsx-author` | R3 | ★★ | QA del libro final antes de firmar |
| | `docx` | R1 | ★★ | Informe narrativo en Word si el banco lo exige |

## 3. Qué no encontré

No hay en estos repositorios un skill público de **validación de modelos de riesgo (MRM / SR 11-7)**, de tiering de modelos, ni de normativa SBS. Esa es justamente la parte que cubren los 46 skills VIRF del paquete.
